from flask import Flask, render_template, request, redirect, url_for,session
import subprocess
import crypt
import pexpect
app = Flask(__name__)
app.secret_key = 'your-secret-key'
# List to store user data
users = []

@app.route('/')
def home():
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    return redirect(url_for('panel'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == 'admin': # user password
            session['logged_in'] = True  # ذخیره وضعیت لاگین کاربر در جلسه
            return redirect(url_for('panel'))
        else:
            return render_template('login.html', message='Invalid username or password.')
    return render_template('login.html')

@app.route('/logout', methods=['GET'])
def logout():
    session.pop('logged_in', None)  # حذف وضعیت لاگین از جلسه
    return redirect(url_for('login'))

@app.route('/panel')
def panel():
    if 'logged_in' not in session:
        return redirect(url_for('login'))
    return render_template('panel.html', users=users)

import subprocess

@app.route('/create_user', methods=['POST'])
def create_user():
    username = request.form['username']
    password = request.form['password']
    expiration_date = request.form['expiration_date']

    # رمزنگاری رمز عبور
    encrypted_password = crypt.crypt(password)

    users.append({'username': username, 'password': encrypted_password, 'expiration_date': expiration_date})
    subprocess.run(['useradd', '-p', encrypted_password, username])
    subprocess.run(['chage', '-E', expiration_date, username])



    return redirect(url_for('panel'))

@app.route('/delete_user', methods=['POST'])
def delete_user():
    username = request.form['username']

    # Kill processes of the user
    pkill_cmd = f"sudo pkill -u {username}"
    pkill_process = pexpect.spawn(pkill_cmd)
    pkill_process.expect(pexpect.EOF)

    # Delete user from the system
    userdel_cmd = f"sudo userdel -r {username}"
    userdel_process = pexpect.spawn(userdel_cmd)
    userdel_process.expect(pexpect.EOF)

    # Remove user from the list
    for user in users:
        if user['username'] == username:
            users.remove(user)
            break
    

    return redirect(url_for('panel'))


if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')

